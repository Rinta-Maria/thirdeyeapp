import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'HOME',
          style: TextStyle(
            color: Color.fromARGB(255, 2, 2, 2),
            fontSize: 30,
          ),
        ),
        centerTitle: true,
        backgroundColor: Color(0xFFA8A7A5),
        leading: IconButton(
          onPressed: () {
            // Handle back button press here
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Color.fromARGB(255, 6, 6, 6),
            size: 35,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // Handle account circle button press here
            },
            icon: const Icon(
              Icons.account_circle,
              color: Color.fromARGB(255, 6, 6, 6),
              size: 35,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Color.fromARGB(255, 255, 255, 255),
                // You can set your desired color or use an image here
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'images/device.png', // Replace with your image asset path
                    width: 300,
                    height: 300,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Connected',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}  